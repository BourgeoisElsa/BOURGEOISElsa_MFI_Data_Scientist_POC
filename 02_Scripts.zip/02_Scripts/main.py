#-*- coding:UTF-8 -*-

#######################################################################
# Spatio-temporal variability of the onset date for the wet season    # 
#                                                                     #
# Data used: ERA5-Land    NetCDF Files                                #
# Study domain: Angola [15°E - 17°E; -13°N - -9°N] including          #
#               Malanje (-9.55°N; 16.34°E)                            #
#               Huambo (-12.77°N; 15.73°E)                            #
# Time period: 1987 - 2010                                            #
#                                                                     #
# Autor: BOURGEOIS Elsa                                               #
# Date: 07/11/2020                                                    #
# Python version used: 3.7.0                                          #
#######################################################################

# Import of libraries
import netCDF4
import numpy as np
import matplotlib as mpl
mpl.use('agg')
from datetime import datetime
from datetime import timedelta
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from mpl_toolkits.basemap import Basemap
from onset_date_computation import liebmann_method

# Variables
path = 'C:/Users/Mathieu/Desktop/MFI_Data_Scientist_POC/'
filename = 'data_angola_1981_2010_total_precipitation_'

# Data from NetCDF files
nc1 = netCDF4.Dataset(path+'01_Data/01_NetCDF/'+filename+'00_to_07UTC.nc','r') 
nc2 = netCDF4.Dataset(path+'01_Data/01_NetCDF/'+filename+'08_to_15UTC.nc','r') 
nc3 = netCDF4.Dataset(path+'01_Data/01_NetCDF/'+filename+'16_to_23UTC.nc','r') 

# Variables list on netCDF file
list_var = nc1.variables
print('List of variables :')
for name_var in list_var:
    print(name_var)
    
# Retrieve of attributes
time_units = nc1.variables['time'].units
tp1_scale_factor = nc1.variables['tp'].scale_factor
tp2_scale_factor = nc2.variables['tp'].scale_factor
tp3_scale_factor = nc3.variables['tp'].scale_factor
tp1_add_offset = nc1.variables['tp'].add_offset
tp2_add_offset = nc2.variables['tp'].add_offset
tp3_add_offset = nc3.variables['tp'].add_offset
total_precipitation_FillValue = nc1.variables['tp']._FillValue # Same value for nc2 and nc3
total_precipitation_missing_value = nc1.variables['tp'].missing_value # Same value for nc2 and nc3

# Reading of variables on netCDF file
longitude = nc1.variables['longitude'][:]  # Longitude in degrees_north
latitude = nc1.variables['latitude'][:]  # Latitude in degrees_east
time1 = nc1.variables['time'][:]
time2 = nc2.variables['time'][:]
time3 = nc3.variables['time'][:]
tp1 = nc1.variables['tp'][:,:,:]
tp2 = nc2.variables['tp'][:,:,:]
tp3 = nc3.variables['tp'][:,:,:]

# Computation of the real value of total_precipitation 
# Be cautious : generation of erroneous values when I used these values, it is the 
# reason that I did not use the scale_factor and the add_offset
# tp1 = tp1 * tp1_scale_factor + tp1_add_offset 
# tp2 = tp2 * tp2_scale_factor + tp2_add_offset 
# tp3 = tp3 * tp3_scale_factor + tp3_add_offset 

# Concatenation of the three periods
time = np.concatenate((time1, time2, time3), axis=0)  # Time in hours since 1900-01-01 00:00:00.0
total_precipitation = np.concatenate((tp1, tp2, tp3), axis=0)  # Total precipitation in meters
# Sort of the data
total_precipitation = total_precipitation[time.argsort()]
time = np.sort(time)

# Conversion in millimeters
total_precipitation = total_precipitation * 1000

# Dates
# Reference time
list_units = time_units.split(" ")
# "strptime" to retrieve a date structure from a chain
reference_date = datetime.strptime(list_units[2]+' '+list_units[3],'%Y-%m-%d %H:%M:%S.%f')
# "time_table" of dimension time, initialised with reference_date
time_table = np.array([reference_date]*time.shape[0])
for index in range(time.shape[0]):
    time_index = float(time[index])
    time_table[index] = reference_date + timedelta(hours = time_index)
    
print ('First time =',time_table[0].strftime('%Y-%m-%d %H:%M:%S.%f'))
print ('Last time =',time_table[-1].strftime('%Y-%m-%d %H:%M:%S.%f'))

# Manipulation for missing_value and _FillValue
total_precipitation[ total_precipitation == total_precipitation_FillValue ] = np.nan
total_precipitation[ total_precipitation == total_precipitation_missing_value ] = np.nan
# Table masked for nan value
total_precipitation = np.ma.masked_array(total_precipitation, np.isnan(total_precipitation))
print ('Min et max of total_precipitation variable :',np.min(total_precipitation),np.max(total_precipitation))

# Determination of the years, the months, the days of the study period
years = np.zeros(len(time_table), dtype = int)
months = np.zeros(len(time_table), dtype = int)
days = np.zeros(len(time_table), dtype = int)
for index in range(time_table.shape[0]):
    years[index] = time_table[index].year
    months[index] = time_table[index].month
    days[index] = time_table[index].day
print('Years of the study period:',np.unique(years))
    
# Number of days during the study period
number_of_days = len(time_table[::24]) # 24 = number of hours during the days

# Retrieve of the total_precipitation matrix
total_precip = total_precipitation.data

# Cumulative precipitation
print('Cumulative precipitation computation')
daily_cumulative_total_precipitation = np.zeros(total_precipitation[::24,:,:].shape, dtype = float) # 24 = number of hours during the days
# Per day
for index in range(number_of_days):
    for ind_lat, lat in enumerate(latitude):
        for ind_lon, lon in enumerate(longitude):
            daily_cumulative_total_precipitation[index,ind_lat,ind_lon] = np.sum(total_precip[24*index:24+(24*(index)),ind_lat,ind_lon]) # 24 = number of hours during the days

# Onset date computation: Liebmann's method
print('Liebmann\'s method to onset date computation')
annual_total_precipitation, daily_mean_total_precipitation, anomalous_accumulation, onset_date = liebmann_method(years[::24], months[::24], days[::24], time_table[::4], latitude, longitude, daily_cumulative_total_precipitation) # 24 = number of hours during the days

# Figures
# For Angola
# Boucle on 1981-1982 to 2009-2010
for index, value in enumerate(np.unique(years)[:-1]):
    fig = plt.figure(figsize=(18,18), dpi=200) # Dimension of the figure
    # Title
    fig.suptitle('Climatology of onset date for the wet season \n[Angola - Africa - ERA5-Land - '+str(value)+' - '+str(value+1)+']', fontsize=18, fontweight='bold')
    fig.subplots_adjust(hspace=0.4,wspace=0.4,left=0.,right=1.,top=0.94)  # Spaces between the graphics
    # Determination of the figure area
    ax1 = plt.subplot(1,1,1)
    # Cartographie / Delimitation of the area study
    latmin = latitude.min() -1
    latmax = latitude.max() +1
    lonmin = longitude.min() -1
    lonmax = longitude.max() +1
    latitude_min = np.floor(np.min(latmin)); latitude_max = np.ceil(np.max(latmax)); longitude_min = np.floor(np.min(lonmin)); longitude_max = np.ceil(np.max(lonmax))
    m = Basemap(projection='cyl', resolution='l', llcrnrlat = latmin, urcrnrlat = latmax, llcrnrlon = lonmin, urcrnrlon = lonmax)
    m.drawcoastlines(linewidth = 0.8) # Coast land/ocean
    m.drawstates(linewidth = 1.4) # Regions
    m.drawcountries(linewidth = 1.4) # Countries
    m.shadedrelief(); # Reliefs
    m.drawparallels(np.arange(latitude_min, latitude_max+0.01, 0.2), labels=[1, 0, 0, 0], size = 14, color='gray', linewidth=0.7)
    m.drawmeridians(np.arange(longitude_min, longitude_max+0.01, 0.2), labels=[0, 0, 0, 1], rotation = 45, size = 14, color='gray', linewidth=0.7)
    # Color map
    colors = np.r_[np.linspace(0.1, 1, len(np.unique(onset_date[:,:,:])))] # One color for one date
    mymap = plt.get_cmap('gist_rainbow')
    my_colors = mymap(colors)
    # Contour of the onset dates
    cp = plt.contourf(longitude, latitude, onset_date[index,:,:], list(np.unique(onset_date[:,:,:])), linewidths=2.)
    # Color bar
    cbar = fig.colorbar(cp, orientation = 'vertical', cax=fig.add_axes([0.85, 0.05, 0.02, 0.90]), ticks = list(np.unique(onset_date[index,:,:])))
    cbar.ax.tick_params(labelsize='18') # Size label on colorbar
    cbar.ax.get_yaxis().labelpad = 40 # Space between the axe and the title
    cbar.ax.set_ylabel('Onset date from the 1st August', fontsize=22., rotation=270) # Title of the color bar
    # Indication of the cities Malanje and Huambo
    ax1.text(16.34, -9.55, 'o', size = 16, fontweight='bold', color = 'w', horizontalalignment='center',verticalalignment='center')
    ax1.text(16.34, -9.45, 'Malanje', size = 20, color = 'w', horizontalalignment='center',verticalalignment='center')
    ax1.text(15.73, -12.77, 'o', size = 16, fontweight='bold', color = 'w', horizontalalignment='center',verticalalignment='center')
    ax1.text(15.73, -12.67, 'Huambo', size = 20, color = 'w', horizontalalignment='center',verticalalignment='center')
    # Legend : titles // size // labelpad : spaces between the axe and the title
    ax1.set_xlabel('Longitude', labelpad=80, fontsize=22.)
    ax1.set_ylabel('Latitude', labelpad=80, fontsize=22.)
    # Save figure
    plt.savefig(path+'03_Figures/'+str(index+1)+'_Angola_Onset_date_'+str(value)+'.png')


# Huambo and Malanje cities

# Position
huambo_position = (-12.77, 15.73)
malanje_position = (-9.55, 16.34)
# Determination of the position of the two cities on the grid map
huambo_position_grid = (np.where(abs(huambo_position[0]-latitude[:]) <= 0.06)[0][0], np.where(abs(huambo_position[1]-longitude[:]) <= 0.06)[0][0])
malanje_position_grid = (np.where(abs(malanje_position[0]-latitude[:]) <= 0.06)[0][0], np.where(abs(malanje_position[1]-longitude[:]) <= 0.06)[0][0])
# Retrieve of the onset date for the two cities on the grid map
huambo_onset_date = onset_date[:,huambo_position_grid[0],huambo_position_grid[1]]
malanje_onset_date = onset_date[:,malanje_position_grid[0],malanje_position_grid[1]]

# Figures

# Function to fit the data
def func(x, a):
    'Linear function to fit the data'
    return a * x

# First figure
fig = plt.figure(figsize=(20,8), dpi=200) # Dimension of the figure
# Title
fig.suptitle('Temporal distribution of onset date for the wet season \n[Huambo and Malanje - ERA5-Land - From 1981 to 2010]', fontsize=14, fontweight='bold')
fig.subplots_adjust(hspace=0.3, wspace=0.3, right=0.96, left=0.1, top=0.92, bottom=0.1)  # Spaces between the graphics
# Determination of the figure area
ax = fig.add_subplot(1,1,1)
# Daily cumulative total precipitation at Huambo and Malanje cities
plt.plot(np.arange(0,daily_cumulative_total_precipitation[:,huambo_position_grid[0],huambo_position_grid[1]].shape[0]),daily_cumulative_total_precipitation[:,huambo_position_grid[0],huambo_position_grid[1]],'b',label='Huambo City (12.77S, 15.73E)')
plt.plot(np.arange(0,daily_cumulative_total_precipitation[:,malanje_position_grid[0],malanje_position_grid[1]].shape[0]),daily_cumulative_total_precipitation[:,malanje_position_grid[0],malanje_position_grid[1]],'r',label='Malanje City (9.55S, 16.34E)')
# Anomalous accumulation at Huambo and Malanje cities
start_period = int(np.where((years[::24] == 1981) & (months[::24] == 8) & (days[::24] == 1))[0])
plt.plot(np.arange(start_period,anomalous_accumulation[:,huambo_position_grid[0],huambo_position_grid[1]].shape[0]+start_period),anomalous_accumulation[:,huambo_position_grid[0],huambo_position_grid[1]],'b--')
plt.plot(np.arange(start_period,anomalous_accumulation[:,malanje_position_grid[0],malanje_position_grid[1]].shape[0]+start_period),anomalous_accumulation[:,malanje_position_grid[0],malanje_position_grid[1]],'r--')
# Legend and axis
ax.legend(loc='upper right',fontsize=10.,labelspacing=.3,numpoints=1,markerscale=1.5, handlelength=2.5, frameon=True)
ax.set_xlim(0,daily_cumulative_total_precipitation[:,huambo_position_grid[0],huambo_position_grid[1]].shape[0])
ax.set_xlabel('Julian day or days',size=12)
ax.set_ylabel('Deviation from mean daily precipitation (mm)',size=12)
# Save figure
plt.savefig(path+'03_Figures/DailyCumulativeTP_AnomalousAccumulation_Huambo_Malanje_1981_2010.png')

# Second figure
fig = plt.figure(figsize=(8,8), dpi=200) # Dimension of the figure
# Title
fig.suptitle('Temporal distribution of onset date for the wet season \n[Huambo and Malanje - ERA5-Land - From 1981 to 2010]', fontsize=14, fontweight='bold')
fig.subplots_adjust(hspace=0.3, wspace=0.3, right=0.96, left=0.1, top=0.92, bottom=0.1)  # Spaces between the graphics
# Determination of the figure area
ax = fig.add_subplot(1,1,1)
# Onset date at Huambo and Malanje cities
plt.scatter(np.unique(years)[:-1], huambo_onset_date+1, s=12, color='b',marker='o',label='Huambo City (12.77S, 15.73E)')
plt.scatter(np.unique(years)[:-1], malanje_onset_date+1, s=12, color='r',marker='o',label='Malanje City (9.55S, 16.34E)')
# Curve fit at Huambo and Malanje cities for
popt1, pcov1 = curve_fit(func, np.unique(years)[:-1], huambo_onset_date+1)
plt.plot(np.unique(years)[:-1],popt1*np.unique(years)[:-1],'b', linewidth=1.)
popt2, pcov2 = curve_fit(func, np.unique(years)[:-1], malanje_onset_date+1)
plt.plot(np.unique(years)[:-1],popt2*np.unique(years)[:-1],'r', linewidth=1.)
# Legend and axis
ax.legend(loc='upper right',fontsize=10.,labelspacing=.3,numpoints=1,markerscale=1.5, handlelength=2.5, frameon=True)
plt.rc("font",size=12)
ax.set_xlim(1980,2010,5)
ax.set_ylim(30,130,5)
ax.set_xlabel('Year',size=12)
ax.set_ylabel('Julian day or days',size=12)
# Grid
plt.grid(True)
# Save figure
plt.savefig(path+'03_Figures/Temporal_distribution_of_onset_date_Huambo_and_Malanje_1981_2010.png')