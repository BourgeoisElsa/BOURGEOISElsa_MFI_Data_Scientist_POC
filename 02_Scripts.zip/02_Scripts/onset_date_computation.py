#-*- coding:UTF-8 -*-

##########################################################################################################
# Function for the computation of the onset date using Liebmann's method                                 #
#                                                                                                        #
# Anomalous Accumulation(t) = precipitation of the day(t) - daily mean of precipitation * t              #
# with daily mean of precipitation = annual cumulation of precipitation / number of the day of the year  #
#      t = day                                                                                           #
#                                                                                                        #
# Autor: BOURGEOIS Elsa                                                                                  #
# Date: 07/11/2020                                                                                       #
# Python version used: 3.7.0                                                                             #
##########################################################################################################

# Import of libraries
import numpy as np

# Function for the computation of the onset date using Liebmann's method
def liebmann_method(years, months, days, time, latitude, longitude, daily_cumulative_total_precipitation):
    
    # Determination of the number of the days per year 
    print('Number of days per year computation')
    # For this study, the year is considered between 01/08/YYYY and 31/07/(YYYY+1) because the monsoon period straddles two years
    number_of_days = np.zeros((np.unique(years).shape[0]-1), dtype = int) # -1 because it straddles on two years
    # Boucle on 1981-1982 to 2009-2010
    for index, value in enumerate(np.unique(years)[:-1]):
        first_period = int(np.where((years == value) & (months >= 8))[0].shape[0])
        second_period = int(np.where((years == value+1) & (months < 8))[0].shape[0])
        number_of_days[index] = first_period + second_period
    #print('Number of days per year:',number_of_days)

    # Determination of the annual cumulation of precipitation 
    print('Annual cumulation of precipitation computation')
    annual_total_precipitation = np.zeros((np.unique(years).shape[0]-1,latitude.shape[0],longitude.shape[0]), dtype = float) # -1 because it straddles on two years
    # Boucle on 1981-1982 to 2009-2010
    for index, value in enumerate(np.unique(years)[:-1]):
        total_precipitation_first_period = np.sum(daily_cumulative_total_precipitation[np.where((years == value) & (months >= 8))[0],:,:], axis=0)
        total_precipitation_second_period = np.sum(daily_cumulative_total_precipitation[np.where((years == value+1) & (months < 8))[0],:,:], axis=0)
        annual_total_precipitation[index,:,:] = total_precipitation_first_period + total_precipitation_second_period

    # Determination of the daily mean of precipitation
    print('Daily mean of precipitation computation')
    daily_mean_total_precipitation = np.zeros((np.unique(years).shape[0]-1,latitude.shape[0],longitude.shape[0]), dtype = float) # -1 because it straddles on two years
    # Boucle on 1981-1982 to 2009-2010
    for index, value in enumerate(np.unique(years)[:-1]):
        daily_mean_total_precipitation[index,:,:] = annual_total_precipitation[index,:,:] / number_of_days[index]

    # Determination of the anomalous accumulation per day
    print('Anomalous accumulation per day computation')
    anomalous_accumulation = np.zeros((np.sum(number_of_days),latitude.shape[0],longitude.shape[0]), dtype = float)
    index_first_day_of_year = 0 # initialisation of index of the day of the year from 1982 to 2010
    number_of_past_days = 0 # initialisation of the day past
    # Boucle on 1981-1982 to 2009-2010
    for index, value in enumerate(np.unique(years)[:-1]):
        first_day = int(np.where((years == value) & (months == 8) & (days == 1))[0])
        cumul_tp = 0 # initialisation for the cumulative total precipitation
        # First year
        if value == 1981:
            for ind_days in range(number_of_days[index]):
                anomalous_accumulation[ind_days,:,:] = (daily_cumulative_total_precipitation[first_day+ind_days,:,:]+cumul_tp) - daily_mean_total_precipitation[index,:,:] * ind_days
                cumul_tp = cumul_tp + daily_cumulative_total_precipitation[first_day+ind_days,:,:]
        # Other years
        elif value != 1981:
            number_of_past_days = number_of_past_days + number_of_days[index-1]
            for ind_days in range(number_of_days[index]):
                index_first_day_of_year = number_of_past_days + ind_days  # Number of days on the year n-1 + number of first day of the year n-1
                anomalous_accumulation[index_first_day_of_year,:,:] = (daily_cumulative_total_precipitation[first_day+ind_days,:,:]+cumul_tp) - daily_mean_total_precipitation[index,:,:] * ind_days
                cumul_tp = cumul_tp + daily_cumulative_total_precipitation[first_day+ind_days,:,:]

    # Determination of the onset date = the day after the day where the minimum of precipitation is observed during the year
    print('Onset date computation')
    onset_date = np.zeros((np.unique(years).shape[0]-1,latitude.shape[0],longitude.shape[0]), dtype = float)
    index_first_day_of_year = 0 # initialisation of index of the day of the year from 1982 to 2010
    # Boucle on 1981-1982 to 2009-2010
    for index, value in enumerate(np.unique(years)[:-1]):
        # First year
        if value != 1981:
            index_first_day_of_year = number_of_days[index-1] + index_first_day_of_year # Number of days on the year n-1 + number of first day of the year n-1
            ind_last_day_of_year = index_first_day_of_year + number_of_days[index] # Number of first day of the year n-1 +¨number of days of the year n
        for ind_lat, lat in enumerate(latitude):
            for ind_lon, lon in enumerate(longitude):
                if value == 1981:
                    onset_date[index,ind_lat,ind_lon] = anomalous_accumulation[0:number_of_days[index],ind_lat,ind_lon].argmin() +1 # +1 = the day after the day where the minimum of precipitation is observed during the year 
                elif value != 1981:
                    onset_date[index,ind_lat,ind_lon] = anomalous_accumulation[index_first_day_of_year:ind_last_day_of_year,ind_lat,ind_lon].argmin() +1 # +1 = the day after the day where the minimum of precipitation is observed during the year 
           
    return(annual_total_precipitation, daily_mean_total_precipitation, anomalous_accumulation, onset_date)